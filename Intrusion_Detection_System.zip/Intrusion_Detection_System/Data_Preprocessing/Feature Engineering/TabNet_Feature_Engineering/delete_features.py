import os
import pandas as pd


def delete_features(df: pd.DataFrame, columns_to_drop: list):
    """
    函数说明：删除DataFrame中特征方差较小的列
    :param df:需要删除特征列的DataFrame
    :param columns_to_drop:包含列名的列表
    :return:返回删除指定特征之后的DataFrame
    """
    df = df.drop(columns=columns_to_drop, errors='ignore')
    return df


def get_features():
    """
    函数说明：从指定位置的txt文件中获取特征重要性数据，获取
    所有特征重要性评分为0的特征名称以及非0的后三个特征名称
    :return: 返回特征名称列表
    """
    file_path = 'G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test\TabNet\\train_log'
    file_name = 'gamma = 1.4feature_importance.txt'
    file_path = os.path.join(file_path, file_name)
    # 需要删除的特征名列表
    result_feature = []
    # 特征-重要性评分字典
    feature_dict = {}

    # 从日志文件中读取特征重要性数据，形成字典
    with open(file_path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            key, value = line.strip().split(' : ')
            feature_dict[key] = float(value)

    # 将重要性评分为0的键值对删除，特征名传入result_feature
    for key, value in list(feature_dict.items()):
        if value == 0.:
            result_feature.append(key)
            del feature_dict[key]

    # last_three_features = list(feature_dict.keys())[-3:]
    # result_feature.extend(last_three_features)
    print(result_feature)
    return result_feature


# original_df = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data\\'
#                           'test.csv')
# deleted_df = delete_features(original_df, get_features())
# deleted_df.to_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data\\'
#                   'test1.csv', index=False)
get_features()
print(len(get_features()))
