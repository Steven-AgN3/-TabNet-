import os
import pandas as pd


def get_feature_names_from_log():
    """
    函数说明：从指定位置的txt文件中获取特征重要性数据
    :return: 返回特征名称列表
    """
    file_path = 'G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test\TabNet\\train_log'
    file_name = 'feature_names.txt'
    file_path = os.path.join(file_path, file_name)

    # 特征-重要性评分字典
    feature_names_dict = {}
    # 特征名称列表
    feature_names = []
    # 从日志文件中读取特征重要性数据，形成字典
    with open(file_path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            key, value = line.strip().split(' : ')
            feature_names_dict[key] = float(value)
    for key in feature_names_dict.keys():
        feature_names.append(key)

    return feature_names


def delete_features(df: pd.DataFrame, columns_to_drop: list):
    """
    函数说明：删除DataFrame中特征方差较小的列
    :param df:需要删除特征列的DataFrame
    :param columns_to_drop:包含列名的列表
    :return:返回删除指定特征之后的DataFrame
    """
    df = df.drop(columns=columns_to_drop, errors='ignore')
    return df


column_names_retain = get_feature_names_from_log()
# origin_feature_name = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data'
#                                   '\Sampled_Composite_data.csv').iloc[:, :-1]
# origin_df = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data'
#                         '\Final_Composite_Dataset.csv')
# origin_names = origin_feature_name.columns.tolist()
# final_feature_names = get_feature_names_from_log()
# delete_names = [i for i in origin_names if i not in final_feature_names]
# print(delete_names)
# final_df = delete_features(origin_df, delete_names)
# final_df.to_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data'
#                 '\Final_Composite_data.csv',
#                 index=False)
print(column_names_retain)