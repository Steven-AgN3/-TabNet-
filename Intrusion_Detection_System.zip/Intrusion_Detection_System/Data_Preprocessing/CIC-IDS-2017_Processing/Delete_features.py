import pandas as pd
from Tool.timer.my_timer import timer

timer.start()


def delete_features(df: pd.DataFrame, columns_to_drop: list):
    """
    函数说明：删除DataFrame中特征方差较小或相关性很大的的列
    :param df:需要删除特征列的DataFrame
    :param columns_to_drop:包含列名的列表
    :return:返回删除指定特征之后的DataFrame
    """
    df = df.drop(columns=columns_to_drop, errors='ignore')
    return df


df = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2017\Processed_data\cleaned_CICIDS2017.csv',
                 low_memory=False)
df = delete_features(df, ['Bwd PSH Flags', 'Bwd URG Flags', 'Fwd Avg Bytes/Bulk',
                          'Fwd Avg Packets/Bulk', 'Fwd Avg Bulk Rate', 'Bwd Avg Bytes/Bulk',
                          'Bwd Avg Packets/Bulk', 'Bwd Avg Bulk Rate', 'Fwd Header Length.1'])
df.to_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2017\Processed_data\\test1\cleaned_1.csv', index=False)

timer.stop_and_print_elapsed_time()
