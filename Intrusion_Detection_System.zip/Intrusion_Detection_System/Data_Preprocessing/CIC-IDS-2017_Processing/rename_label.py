import pandas as pd


def rename_label(df_: pd.DataFrame):
    """
    函数说明: 整理含有乱码的标签
    :param df: 需整理的DataFrame
    :return: 返回处理后的DataFrame
    """

    # 将 Label 列的值为 "BENIGN" 的所有行重命名为 "Benign"
    df_.loc[df['Label'] == 'BENIGN', 'Label'] = 'Benign'

    return df_


file_path = 'G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2017\Processed_data\cleaned_CIC-IDS-2017.csv'
df = pd.read_csv(file_path, low_memory=False)
df = rename_label(df)
df.to_csv(file_path, index=False)
print(df.head())