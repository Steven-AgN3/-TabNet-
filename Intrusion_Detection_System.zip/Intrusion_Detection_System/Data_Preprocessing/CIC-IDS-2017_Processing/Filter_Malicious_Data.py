"""
删除CIC-IDS-2017数据集中所有除标签为BENIGN以外的数据，保留其中的良性流量数据；
目的是在CIC-IDS-2017数据集的基础上扩充良性流量数据，达到数据平衡的目的（自编码器数据集）
"""


import pandas as pd
from Tool.timer.my_timer import timer

timer.start()

df = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2017\Processed_data\Composite_Dataset\cleaned_CIC-IDS-2017.csv')
# 保留 'Label' 列值为 'Benign' 的行
df = df[df['Label'] == 'Benign']
df.to_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2017\Processed_data\Benign_Dataset\Benign_CIC-IDS-2017.csv',
          index=False)

timer.stop_and_print_elapsed_time()
