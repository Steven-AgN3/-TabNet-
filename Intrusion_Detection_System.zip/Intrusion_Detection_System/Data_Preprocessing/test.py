import pandas as pd

df = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Merged_Benign_Data\Final_Benign_Data.csv')
print(df.head())