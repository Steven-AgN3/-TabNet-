import pandas as pd
from sklearn.preprocessing import StandardScaler

# 读取原始 CSV 文件
input_file_path = 'G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data\Sampled_Composite_data.csv'
df = pd.read_csv(input_file_path)

# 提取数据进行规范化处理
features = df.iloc[:, :-1]  # 提取数据
scaler = StandardScaler()  # 使用StandardScaler进行z-score标准化
normalized_features = scaler.fit_transform(features)

# 将标签列拼接到规范化后的数据的最后一列
normalized_data = pd.DataFrame(normalized_features, columns=features.columns)
normalized_data['Label'] = df['Label']  # 假设标签列名为 'Label'

# 将规范化后的数据写入新的 CSV 文件
output_file_path = 'G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data\Sampled_normalized_data.csv'
normalized_data.to_csv(output_file_path, index=False)

# 显示处理后的 DataFrame
print(normalized_data.head())


