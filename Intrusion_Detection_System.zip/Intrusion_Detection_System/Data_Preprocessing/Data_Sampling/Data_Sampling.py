import pandas as pd

# 读取完整数据集
full_dataset = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data\Balanced_data'
                           '\\Balanced_Composite_Dataset.csv',
                           low_memory=False)

# 初始化一个DataFrame，用于存储抽取的数据
sampled_data = pd.DataFrame()

# 对每一种标签进行抽取
for label in full_dataset['Label'].unique():
    # 选择具有特定标签的数据
    label_data = full_dataset[full_dataset['Label'] == label]

    # 将样本数小于100的标签全部包含在训练集中
    if len(label_data) < 2000:
        sampled_data = pd.concat([sampled_data, label_data])
    else:
        # 抽取1%的数据
        sampled_label_data = label_data.sample(frac=0.01, random_state=42)

        # 将抽取的数据添加到新的DataFrame中
        sampled_data = pd.concat([sampled_data, sampled_label_data])

# 将抽取的数据保存到新的CSV文件
sampled_data.to_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data\Sampled_Composite_data.csv',
                    index=False)