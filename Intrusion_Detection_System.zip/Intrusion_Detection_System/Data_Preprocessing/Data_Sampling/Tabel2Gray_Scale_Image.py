import os
import pandas as pd
import numpy as np
import cv2


normalized_data = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data\\normalized_composite_data.csv')
label_values = normalized_data['Label'].unique().tolist()
counts_dict = {label: 0 for label in label_values}
features_data = normalized_data.iloc[:, :-1]

for index, row in normalized_data.iterrows():
    features = row.iloc[:-1].values
    label = row.iloc[-1]
    # 将每个row扩展为78x78的矩阵并添加到数组中
    extended_matrix = np.tile(features, (78, 1))
    img_matrix = extended_matrix.astype(np.uint8)
    # 创建图像
    image_name = f'{label}_{counts_dict[label]}.png'
    image_path = os.path.join('G:\\test_img', image_name)

    # 将扩展矩阵保存为灰度图像
    cv2.imwrite(image_path, img_matrix)

    # 更新字典中对应标签的计数
    counts_dict[label] += 1

print(counts_dict)

