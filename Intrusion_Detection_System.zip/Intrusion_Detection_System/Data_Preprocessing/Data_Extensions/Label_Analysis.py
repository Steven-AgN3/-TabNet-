import os
import pandas as pd
from Tool.timer.my_timer import timer

# 计时器初始化
timer.start()
file_path = 'G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data\Balanced_data'
csv_path = os.path.join(file_path, 'Balanced_Composite_Dataset.csv')
df = pd.read_csv(csv_path, low_memory=False, encoding='utf-8')
label_counts = df['Label'].value_counts()

# 将label_counts的数据写入txt文件
txt_file_path = os.path.join(file_path, 'label_counts.txt')
with open(txt_file_path, 'a+', encoding='utf-8') as txt_file:
    txt_file.write("Label Counts:\n")
    txt_file.write(label_counts.to_string())
    txt_file.write("\n\n")

# 打印统计结果
print("Label Counts:\n", label_counts)

# 结束计时
timer.stop_and_print_elapsed_time()