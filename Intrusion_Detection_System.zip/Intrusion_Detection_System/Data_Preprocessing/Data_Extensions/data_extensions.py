import pandas as pd
from Tool.timer.my_timer import timer

timer.start()


def oversample_csv(csv_path, target_csv_path, target_samples=4000):
    # 读取原始 CSV 文件
    df = pd.read_csv(csv_path)

    # 统计每个类别的样本数
    label_counts = df['Label'].value_counts()

    # 处理样本数不足的类别
    for label, count in label_counts.items():
        if count < target_samples:
            # 计算需要复制的样本数
            oversample_count = target_samples - count

            # 获取当前类别的样本
            samples_to_oversample = df[df['Label'] == label]

            # 随机抽样并复制样本，使样本数量达到 target_samples
            oversampled_samples = samples_to_oversample.sample(n=oversample_count, replace=True)

            # 将扩充后的样本追加到原始数据框
            df = pd.concat([df, oversampled_samples], ignore_index=True)

    # 将扩充后的数据保存到目标 CSV 文件
    df.to_csv(target_csv_path, index=False)


if __name__ == "__main__":
    # 指定输入和输出路径
    input_csv_path = 'G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data\Final_Composite_Dataset.csv'
    output_csv_path = 'G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data\Balanced_data' \
                      '\Balanced_Composite_Dataset.csv '

    # 执行过采样
    oversample_csv(input_csv_path, output_csv_path)
timer.stop_and_print_elapsed_time()