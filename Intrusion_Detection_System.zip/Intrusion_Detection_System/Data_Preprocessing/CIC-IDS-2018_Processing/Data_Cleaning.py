import pandas as pd
import numpy as np


df_ = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\Processed_data\Benign_Data\CIC-IDS-2018_Benign.csv',
                  low_memory=False)
df_cleaned = df_.replace(np.inf, np.nan).dropna()
df_cleaned.to_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\Processed_data\Benign_Data\CIC-IDS-2018_Benign.csv',
                  index=False)