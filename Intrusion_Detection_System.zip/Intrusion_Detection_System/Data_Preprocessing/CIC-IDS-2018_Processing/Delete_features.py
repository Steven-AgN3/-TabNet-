import pandas as pd
from Tool.timer.my_timer import timer

timer.start()


def delete_features(df: pd.DataFrame, columns_to_drop: list):
    """
    函数说明：删除DataFrame中特征方差较小或相关性很大的的列
    :param df:需要删除特征列的DataFrame
    :param columns_to_drop:包含列名的列表
    :return:返回删除指定特征之后的DataFrame
    """
    df = df.drop(columns=columns_to_drop, errors='ignore')
    return df


df_2018 = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\Processed_data\Benign_Data\CIC-IDS-2018_Benign.csv',
                      low_memory=False)
df_2018 = delete_features(df_2018, ['Protocol', 'Bwd PSH Flags', 'Bwd URG Flags', 'Fwd Byts/b Avg',
                                    'Fwd Pkts/b Avg', 'Fwd Blk Rate Avg', 'Bwd Byts/b Avg', 'Bwd Pkts/b Avg',
                                    'Bwd Blk Rate Avg', 'Timestamp'])
df_2018.to_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\Processed_data\Benign_Data\CIC-IDS-2018_Benign.csv',
               index=False)

timer.stop_and_print_elapsed_time()
