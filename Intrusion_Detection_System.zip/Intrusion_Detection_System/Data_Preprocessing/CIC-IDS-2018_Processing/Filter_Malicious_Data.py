"""
删除CIC-IDS-2018数据集中所有除标签为BENIGN以外的数据，保留其中的良性流量数据；
目的是在CIC-IDS-2017数据集的基础上扩充良性流量数据，达到数据平衡的目的（自编码器数据集）
"""


import os
import pandas as pd
from tqdm import tqdm
from Tool.timer.my_timer import timer

timer.start()


def process_csv_files(folder_path):
    # 获取文件夹中的所有文件和子文件夹
    files_and_subfolders = os.listdir(folder_path)
    # 进度条初始化
    for item in tqdm(files_and_subfolders, desc='Processing CSV files'):
        item_path = os.path.join(folder_path, item)

        if os.path.isdir(item_path):
            # 递归处理子文件夹
            process_csv_files(item_path)
        elif item.endswith('.csv'):
            # 处理 CSV 文件
            csv_file_path = item_path
            df = pd.read_csv(csv_file_path, low_memory=False)

            # 保留 'Label' 列值为 'BENIGN' 的行
            df = df[df['Label'] == 'Benign']

            # 将处理后的 DataFrame 重新写入原文件
            df.to_csv(csv_file_path, index=False)


folder_path_ = 'G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\origin_data\Benign_Data'
process_csv_files(folder_path_)

timer.stop_and_print_elapsed_time()
