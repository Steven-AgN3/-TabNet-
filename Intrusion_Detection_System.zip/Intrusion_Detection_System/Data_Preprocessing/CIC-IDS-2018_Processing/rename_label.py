import pandas as pd
import pandas


def rename_label(df: pandas.DataFrame):
    """
    函数说明: 整理含有乱码的标签
    :param df: 需整理的DataFrame
    :return: 返回处理后的DataFrame
    """
    # 使用 str.contains 检查子串，并根据匹配结果重命名
    df.loc[df['Label'].str.contains('DoS attacks-Hulk'), 'Label'] = 'DoS Hulk'
    df.loc[df['Label'].str.contains('FTP-BruteForce'), 'Label'] = 'FTP-Patator'
    df.loc[df['Label'].str.contains('SSH-Bruteforce'), 'Label'] = 'SSH-Patator'
    df.loc[df['Label'].str.contains('SlowHTTPTest'), 'Label'] = 'DoS Slowhttptest '
    df.loc[df['Label'].str.contains('GoldenEye'), 'Label'] = 'DoS GoldenEye'
    df.loc[df['Label'].str.contains('Slowloris'), 'Label'] = 'DoS slowloris'
    df.loc[df['Label'].str.contains('Brute Force -Web'), 'Label'] = 'Web Attack-Brute Force'
    df.loc[df['Label'].str.contains('Brute Force -XSS'), 'Label'] = 'Web Attack-XSS'
    df.loc[df['Label'].str.contains('SQL'), 'Label'] = 'Web Attack-SQL Injection'
    return df


def rename_columns(df_: pandas.DataFrame, columns_rename_list: list):
    """
    函数说明: 重命名列名
    :param df_: 需重命名的DataFrame
    :param columns_rename_list: 重命名的目标列名列表
    :return: 返回处理后的DataFrame
    """
    # 使用列表中的列名为 B 的每一列重新命名
    df_.columns = columns_rename_list
    return df_


# df = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\Processed_data\Benign_Data\CIC-IDS-2018_Benign.csv')

# df1 = rename_label(df)
# 读取 A.csv 文件，获取列名列表
file_2017 = 'G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2017\Processed_data\cleaned_1.csv'
df_2017 = pd.read_csv(file_2017)
column_names_2017 = df_2017.columns.tolist()

df_2018 = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\Processed_data\Benign_Data\CIC-IDS-2018_Benign.csv',
                      low_memory=False)
df_2018 = rename_columns(df_2018, column_names_2017)
df_2018.to_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\Processed_data\Benign_Data\\rename_CIC-IDS-2018_Benign.csv',
               index=False)
