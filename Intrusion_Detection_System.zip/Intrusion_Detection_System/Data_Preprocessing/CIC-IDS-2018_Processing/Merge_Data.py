import os
import pandas as pd
from Tool.timer.my_timer import timer
from tqdm import tqdm

# 计时器初始化
timer.start()
# 定义文件夹路径
folder_path = 'G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\origin_data\Benign_Data'
file_list = os.listdir(folder_path)
csv_files = [file for file in file_list if file.endswith('.csv')]

# 初始化一个空的DataFrame
combined_data = pd.DataFrame()
# 初始化进度条
progress_bar = tqdm(total=len(csv_files), desc='Processing')
# 逐个读取CSV文件并拼接
for file in csv_files:
    file_path = os.path.join(folder_path, file)
    df = pd.read_csv(file_path, low_memory=False)
    combined_data = pd.concat([combined_data, df], ignore_index=True)
    # 更新进度条状态
    progress_bar.update(1)
# 关闭进度条
progress_bar.close()

# 将合并后的数据保存到新的CSV文件中
combined_data.to_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\Processed_data\Benign_Data\CIC-IDS-2018_Benign.csv',
                     index=False)
# 结束计时
timer.stop_and_print_elapsed_time()