import pandas as pd

df = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data\Final_Composite_Dataset.csv')

# df = df[df['Label'] != 'Infiltration']
df.loc[df['Label'].str.contains('Inf'), 'Label'] = 'Infiltration'

df.to_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data\Final_Composite_Dataset.csv', index=False)