import os
import pandas as pd
import numpy as np
from Tool.timer.my_timer import timer

# 计时器初始化
timer.start()

data = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data\Balanced_data\\normalized_data.csv')
no_label_data = data.drop('Label', axis=1)
# 计算方差
variances_per_column = no_label_data.var()
# 计算均值
mean_per_column = no_label_data.mean()
# 计算中位数
media_per_column = no_label_data.median()
# 计算标准差
std_per_column = no_label_data.std()
# 显示列数据类型
data_types = no_label_data.dtypes
# 计算相关性矩阵
correlation_matrix = no_label_data.corr()
# 合并方差和均值为一个DataFrame，将第一列命名为'feature'
stats_data = pd.DataFrame({'feature': variances_per_column.index, 'Variances': variances_per_column,
                            'media': media_per_column, 'std': std_per_column,
                           'types': data_types})


out_path = 'G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data\Balanced_data'
# 将合并后的数据保存到CSV文件
stats_data.to_csv(os.path.join(out_path, 'normalized_composite_stats_data.csv'), index=False)

# 对correlation_matrix中的值进行处理，相关度在-0.90到0.90之间，删除，之保留相关度在(-1, -0.90)以及(0.90, 1)的值
correlation_matrix_processed = correlation_matrix.applymap(lambda x: x if (-0.90 <= x <= -1)
                                                            or (0.90 <= x <= 1) else np.nan)
correlation_matrix_processed.to_csv(os.path.join(out_path, 'normalized_composite_Datacorrelation_matrix.csv'))

# 计时器结束
timer.stop_and_print_elapsed_time()