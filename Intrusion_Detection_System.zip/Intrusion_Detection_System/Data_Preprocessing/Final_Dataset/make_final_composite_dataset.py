import pandas as pd

df_2017 = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2017\Processed_data\\test1\cleaned_1.csv', low_memory=False)
df_2018 = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\CIC-IDS-2018\Processed_data\cleaned_CICIDS2018.csv', low_memory=False)

final_dataset = pd.concat([df_2017, df_2018], ignore_index=True)

final_dataset.to_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Final_Dataset.csv', index=False)
print(final_dataset.head)