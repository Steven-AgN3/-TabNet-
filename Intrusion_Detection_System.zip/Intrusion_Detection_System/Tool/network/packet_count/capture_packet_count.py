import pyshark


def get_act_data_pkt_fwd():
    pass


def get_ack_flag_count():
    pass


def get_ece_flag_count():
    pass


def get_psh_flag_count():
    pass


def get_rst_flag_count():
    pass


def get_fin_flag_count():
    pass


def get_urg_flag_count():
    pass


def get_fwd_psh_flag_count():
    pass