from Tool.network.traffic_statistics.capture_statidtics import *


class TrafficAnalyzer:
    def __init__(self, listener_):
        self.listener_ = listener_

    def analyze_traffic(self):
        # 持续从TrafficListener中获取监听得到的流量数据
        a = 1
        while a:

            pcap_path = self.listener_.get_pcap_path()
            print(pcap_path)
            a -= 1

