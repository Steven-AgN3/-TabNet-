import pyshark


def get_fwd_iat_total():
    pass


def get_flow_iat_std():
    pass


def get_bwd_iat_std():
    pass


def get_fwd_iat_mean():
    pass


def get_bwd_iat_total():
    pass


def get_fwd_iat_max():
    pass