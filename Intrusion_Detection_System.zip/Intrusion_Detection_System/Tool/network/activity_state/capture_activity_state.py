import pyshark


def get_active_min():
    pass


def get_active_std():
    pass


def get_active_mean():
    pass


def get_idle_min():
    pass