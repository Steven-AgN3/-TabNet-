import pyshark


def get_min_packet_length():
    pass


def get_packet_length_mean():
    pass


def get_avg_fwd_segment_size():
    pass


def get_packet_length_variance():
    pass


def get_bwd_packet_length_max():
    pass


def get_bwd_packet_length_std():
    pass


def get_fwd_packet_length_max():
    pass


def get_fwd_packet_length_std():
    pass


def get_packet_length_std():
    pass