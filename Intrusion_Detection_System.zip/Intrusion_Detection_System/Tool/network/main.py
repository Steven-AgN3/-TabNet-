import threading
from Tool.network.traffic_listener import TrafficListener
from Tool.network.traffic_analyzer import TrafficAnalyzer

if __name__ == "__main__":
    listener = TrafficListener()
    analyzer = TrafficAnalyzer(listener)

    # 在单独的线程中启动监听器
    listener_thread = threading.Thread(target=listener.start_listening,
                                       args=("以太网",))
    listener_thread.start()

    # 启动流量分析器
    analyzer.analyze_traffic()

    # 在完成后可选择停止监听器
    listener.stop_listening()
    listener_thread.join()
