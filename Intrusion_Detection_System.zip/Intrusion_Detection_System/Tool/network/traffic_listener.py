from scapy.all import *
import threading
from queue import Queue


class TrafficListener:
    def __init__(self):
        # 初始化数据队列和停止事件
        self.data_queue = Queue()
        self.stop_event = threading.Event()
        # 初始化计数器和 pcap 文件名
        self.packet_count = 0
        self.current_filename = self.generate_filename()

    def start_listening(self, interface):
        try:
            while True:
                # 检查停止事件是否被设置，如果是，则退出循环
                if self.stop_event.is_set():
                    break

                sniff(iface=interface, count=1000, filter='tcp or udp', prn=self.callback)
        except KeyboardInterrupt:
            # 用户手动终止监听时的处理
            print('用户终止监听！')

    @staticmethod
    def generate_filename():
        # 生成文件名
        now_time = datetime.now().strftime("%Y%m%d%H%M%S")
        filename = os.path.join(r"G:\人工智能方向课\项目实训\temp", f"{now_time}.pcap")
        print(filename)
        return filename

    def callback(self, packet_):
        # 回调函数
        # 将捕获到的流量数据写入当前 pcap 文件
        with PcapWriter(self.current_filename, append=True) as o_open_file:
            packet_.show()
            o_open_file.write(packet_)
            self.packet_count += 1

            # 当达到150个数据包时，保存文件并重置计数器和文件名
            if self.packet_count == 1000:
                self.data_queue.put(self.current_filename)
                self.packet_count = 0
                self.current_filename = self.generate_filename()

    def stop_listening(self):
        # 设置停止事件，通知监听线程停止
        self.stop_event.set()

    def get_pcap_path(self):
        # 从队列获取pcap文件绝对路径
        return self.data_queue.get()

