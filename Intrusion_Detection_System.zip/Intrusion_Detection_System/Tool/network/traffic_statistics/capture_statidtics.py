import pyshark


def get_destination_port(traffic_data: list):
    """
    函数说明: 从传入的数据包中获取目标端口信息
    :param traffic_data: 长度为51的列表，其中含有50个数据包信息和一个时间戳信息
    :return: 返回数据包的目标端口号
    """
    # 目标端口号列表
    dstport_list = []
    for i in traffic_data:
        try:
            dstport_list.append(int(i[2].dstport))
        except AttributeError:
            dstport_list.append('AttributeError')
            continue
        except IndexError:
            dstport_list.append('IndexError')
            continue
    return dstport_list


def get_fwd_packets_rate():
    pass


def get_bwd_packets_rate():
    pass


def get_flow_packets_rate():
    pass


def get_flow_bytes_rate():
    pass


def get_total_backward_packets():
    pass


def get_total_forward_packets():
    pass


def get_total_length_of_bwd_packets():
    pass


def get_subflow_fwd_bytes():
    pass


def get_subflow_bwd_bytes():
    pass
