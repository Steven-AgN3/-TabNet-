import time


class Timer:
    def __init__(self):
        self.start_time = None
        self.end_time = None

    def start(self):
        self.start_time = time.time()

    def stop(self):
        self.end_time = time.time()

    def elapsed_time(self):
        if self.start_time is None:
            return None
        if self.end_time is None:
            self.end_time = time.time()
            return self.end_time - self.start_time
        elapsed_time = self.end_time - self.start_time
        return elapsed_time

    def stop_and_print_elapsed_time(self):
        self.end_time = time.time()
        if self.start_time is None or self.end_time is None:
            return None
        elapsed_time = self.end_time - self.start_time
        print(f"代码运行时间为：{elapsed_time}s")
        return elapsed_time


timer = Timer()
