import torch


def device_detection():
    """
    函数说明: 设备检测
    :return: 无返回值
    """

    # 检查GPU是否可用
    if torch.cuda.is_available():
        # 获取GPU设备
        device = torch.device("cuda:0")
        # 获取当前GPU的显存信息
        gpu_properties = torch.cuda.get_device_properties(device)
        print(f"GPU名称: {gpu_properties.name}")
        print(f"GPU总显存: {gpu_properties.total_memory / (1024 ** 3):.2f} GB")
        print(f"已使用显存: {torch.cuda.memory_allocated(device) / (1024 ** 3):.2f} GB")
        print(
            f"剩余显存: {gpu_properties.total_memory / (1024 ** 3) - torch.cuda.memory_allocated(device) / (1024 ** 3):.2f} GB")
    else:
        print("没有可用的GPU。")


if __name__ == '__main__':
    device_detection()
