import os

# 打开文件并读取数据
from matplotlib import pyplot as plt

file_path = "G:\人工智能方向课\项目实训\过程数据\Tabnet"  # 替换为你的文件路径
train_list = []
test_list = []

try:
    with open(os.path.join(file_path, 'train_accuracy.txt'), 'r') as file:
        # 逐行读取文件内容并将每行的数据转换为浮点数
        for line in file:
            data_point = float(line.strip())  # 移除首尾空白并转换为浮点数
            train_list.append(data_point)
except FileNotFoundError:
    print(f"文件 '{file_path}' 未找到.")

try:
    with open(os.path.join(file_path, 'test_accuracy.txt'), 'r') as file:
        # 逐行读取文件内容并将每行的数据转换为浮点数
        for line in file:
            data_point = float(line.strip())  # 移除首尾空白并转换为浮点数
            test_list.append(data_point)
except FileNotFoundError:
    print(f"文件 '{file_path}' 未找到.")


plt.figure(figsize=(10, 7))
plt.title("Accuracy about epochs")
plt.plot([i for i in range(256)], train_list,
         marker='o', linestyle='-', label='train accuracy')
plt.plot([i for i in range(256)], test_list,
         marker='o', linestyle='-', label='test accuracy')
plt.legend()  # 添加图例
plt.show()
