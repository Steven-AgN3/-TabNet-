import os
import torch
import pandas as pd
from matplotlib import pyplot as plt
from Tool.timer.my_timer import timer
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from pytorch_tabnet.tab_model import TabNetClassifier

timer.start()
# 读取采样获得的数据集
sampled_dataset = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data\\'
                              'Sampled_Composite_data.csv')
# 获取列名
column_names = sampled_dataset.columns.tolist()

# 训练日志路径
log_path = 'G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test\TabNet\\train_log'

# 将标签编码为整数
label_encoder = LabelEncoder()
sampled_dataset['Label'] = label_encoder.fit_transform(sampled_dataset['Label'])

# 划分特征和标签
X = sampled_dataset.iloc[:, :-1].values
y = sampled_dataset.iloc[:, -1].values

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
# 定义epochs和batch_size
epochs = 128
batch_size = 2048

# 模型初始化
clf = TabNetClassifier(n_d=64, n_a=64, n_steps=5,
                       gamma=1.4, n_independent=2, n_shared=2,
                       device_name="cuda",
                       cat_emb_dim=1,
                       lambda_sparse=0.0001, momentum=0.2,
                       optimizer_fn=torch.optim.Adam,
                       optimizer_params=dict(lr=2e-2),
                       scheduler_params={"gamma": 0.95,
                                         "step_size": 10},
                       scheduler_fn=torch.optim.lr_scheduler.StepLR, epsilon=1e-15)


def train_model():
    # 训练模型
    clf.fit(X_train=X_train, y_train=y_train,
            eval_set=[(X_train, y_train), (X_test, y_test)],
            eval_name=['train', 'test'],
            eval_metric=['accuracy'],
            max_epochs=epochs,
            batch_size=batch_size,
            patience=100,
            )

    # 绘图
    # 损失函数折线图
    plt.figure(figsize=(8, 6))
    plt.title("Loss")
    plt.plot([i for i in range(epochs)], clf.history['loss'], marker='o', linestyle='-')
    plt.show()

    # 准确率折线图
    plt.figure(figsize=(8, 6))
    plt.title("Accuracy")
    plt.plot([i for i in range(epochs)], clf.history['train_accuracy'],
             marker='o', linestyle='-', label='train accuracy')
    plt.plot([i for i in range(epochs)], clf.history['test_accuracy'],
             marker='o', linestyle='-', label='test accuracy')
    plt.legend()
    plt.show()

    # 绘制特征重要性评分柱状图
    plt.figure(figsize=(16, 8))
    plt.title('Feature Importance')
    labels = [i for i in range(len(clf.feature_importances_))]

    # 绘制柱状图
    plt.bar(range(len(clf.feature_importances_)), clf.feature_importances_,
            tick_label=labels, width=2.0)

    # 在每个柱子上添加横坐标和纵坐标标签，并加粗柱子
    for i, value in enumerate(clf.feature_importances_):
        plt.text(i, value + 0.001, f'{value:.3f}', ha='center', va='bottom')

    plt.xlabel('Features')
    plt.ylabel('Importance Score')
    plt.show()

    # 生成重要性评分字典
    feature_importance_dict = dict(zip(column_names, list(clf.feature_importances_)))
    feature_importance_dict = dict(sorted(feature_importance_dict.items(), key=lambda item: item[1], reverse=True))
    # 将特征重要性评分写入日志文件
    _ = os.path.join(log_path, f'gamma = {clf.gamma}feature_importance.txt')
    with open(_, 'a+') as txt_file:
        for key, value in feature_importance_dict.items():
            txt_file.write(f'{key} : {value}\n')


def save_model():
    """
    函数说明：保存最佳模型文件
    :return: 无返回值
    """
    # 保存模型
    model_path = 'G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test\TabNet\TabNet_model'
    model_path = os.path.join(model_path, 'TabNet_model')
    clf.save_model(model_path)


def load_model_and_predict():
    """
    函数说明：加载模型文件, 并进行预测
    :return: 无返回值
    """
    # 加载模型
    model_path = 'G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test\TabNet\TabNet_model'
    saved_filename = os.path.join(model_path, 'TabNet_model.zip')
    loaded_clf = TabNetClassifier()
    loaded_clf.load_model(saved_filename)
    loaded_predict = loaded_clf.predict(X_test)
    accuracy = accuracy_score(y_test, loaded_predict)
    print(f'最佳模型的预测正确率为：{accuracy}')


train_model()
save_model()
load_model_and_predict()

timer.stop_and_print_elapsed_time()
