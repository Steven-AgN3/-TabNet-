import os
import torch
import numpy as np
import pandas as pd
from itertools import product
from Tool.timer.my_timer import timer
from seqeval.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from pytorch_tabnet.tab_model import TabNetClassifier

timer.start()

# 读取采样获得的数据集
sampled_dataset = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data\\'
                              'Sampled_Composite_data.csv')

# 将标签编码为整数
label_encoder = LabelEncoder()
sampled_dataset['Label'] = label_encoder.fit_transform(sampled_dataset['Label'])

# 划分特征和标签
X = sampled_dataset.iloc[:, :-1].values
y = sampled_dataset.iloc[:, -1].values

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 定义epochs和batch_size
epochs = 10
batch_size = 2048


def write_log(df, params_, score_):
    """
    函数说明：将准确率较高的参数写入DataFrame方便后续保存为csv或Excel文件
    :param df: 待写入的DataFrame
    :param params_: 需要写入的参数
    :param score_: 模型评分
    :return: 返回日志信息DataFrame
    """
    new_row = {'Accuracy': score_, 'Parameters': [params_]}
    df = pd.concat([df, pd.DataFrame(new_row)], ignore_index=True)
    return df


def grid_search(X_train_, y_train_, X_val, y_val, hyperparameter_search_space_):
    """
    函数说明：自定义网格搜索函数
    :param X_train_: 训练集特征值
    :param y_train_: 训练集标签值
    :param X_val: 验证集特征值
    :param y_val: 验证集标签值
    :param hyperparameter_search_space_: 超参数搜索空间
    :return: 返回最佳模型的参数字典和准确率
    """
    # 搜索序号初始化
    search_id = 0
    # 初始化日志信息DataFrame
    log_df = pd.DataFrame(columns=['Accuracy', 'Parameters'])
    # 初始化最佳模型的参数字典和准确率
    best_params_ = None
    best_score_ = float('-inf')  # 初始化为一个很小的值

    # 遍历所有超参数组合
    all_combinations = []
    for params_values in product(*hyperparameter_search_space_.values()):
        # 设置 'n_a' 参数为与 'n_d' 相同的值
        params_dict = dict(zip(hyperparameter_search_space_.keys(), params_values))
        params_dict['n_a'] = params_dict['n_d']
        all_combinations.append(params_dict)

    for params in all_combinations:
        model = TabNetClassifier(**params,
                                 device_name='cuda',
                                 optimizer_params=dict(lr=2e-2),
                                 optimizer_fn=torch.optim.Adam,
                                 scheduler_fn=torch.optim.lr_scheduler.StepLR,
                                 scheduler_params={"gamma": 0.95,
                                                   "step_size": 20}
                                 )
        model.fit(X_train=X_train_, y_train=y_train_,
                  eval_set=[(X_val, y_val)],
                  eval_name=['test'],
                  eval_metric=['accuracy'],
                  max_epochs=epochs,
                  batch_size=batch_size,
                  patience=100)

        # 获取模型的最佳准确率评分
        val_accuracy = np.round(np.max(model.history['test_accuracy']), 5)
        print(f'当前模型的验证集准确率为：{val_accuracy}')

        # 将模型的准确率大于0.93的模型参数和准确率写入DataFrame, 注意按需更改该阈值！
        if val_accuracy >= 0.93:
            log_df = write_log(log_df, params, val_accuracy)

        # 如果当前模型表现更好，则更新最佳超参数和分数
        if val_accuracy > best_score_:
            best_score_ = val_accuracy
            best_params_ = params
        with open('G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test'
                  '\TabNet\\train_log\\training_processing.txt', 'w') as f:
            search_id += 1
            f.write(f'完成训练第{search_id}个模型，\n参数为：{params}，\n准确率为：{val_accuracy}')

    # 循环结束后将日志信息写入csv文件
    log_df.to_csv('G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test\TabNet\\train_log'
                  '\\train_log.csv', index=True)

    return best_params_, best_score_


def load_model_and_predict():
    """
    函数说明：加载模型文件, 并进行预测
    :return: 无返回值
    """
    # 加载模型
    model_path = 'G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test\TabNet\TabNet_model'
    saved_filename = os.path.join(model_path, 'TabNet_model.zip')
    loaded_clf = TabNetClassifier()
    loaded_clf.load_model(saved_filename)
    loaded_predict = loaded_clf.predict(X_test)
    accuracy = accuracy_score(y_test, loaded_predict)
    print(f'最佳模型的预测正确率为：{accuracy}')


hyperparameter_search_space = {
    'n_d': [32, 64, 128],
    'gamma': [1.4, 1.41, 1.42, 1.80, 1.81, 1.82, 1.83],
    'n_steps': [4, 5, 6, 7, 8, 9],
    'lambda_sparse': [1e-3, 1e-4, 1e-5, 1e-6],
    'momentum': [0.05, 0.1, 0.2, 0.3, 0.4],
}

best_params, best_score = grid_search(X_train, y_train, X_test, y_test, hyperparameter_search_space)
# load_model_and_predict()
print(best_params, best_score)

timer.stop_and_print_elapsed_time()
