import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

conf_matrix = np.array([
    [9676, 0, 1, 2, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0],  # 1
    [2, 483, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],  # 2
    [1, 0, 201, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 3
    [1, 0, 0, 130, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],  # 4
    [1, 0, 0, 1, 132, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 5
    [0, 0, 0, 0, 0, 102, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0],  # 6
    [0, 0, 0, 1, 0, 0, 95, 0, 15, 0, 0, 0, 0, 0, 0, 0],  # 7
    [1, 0, 0, 1, 0, 0, 0, 98, 0, 0, 0, 0, 0, 0, 0, 0],  # 8
    [0, 0, 0, 0, 0, 0, 12, 0, 78, 0, 2, 0, 0, 0, 0, 0],  # 9
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 37, 0, 0, 0, 0, 0, 0],  # 10
    [2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0],  # 11
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0],  # 12
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0],  # 13
    [2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0],  # 14
    [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0],  # 15
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3]  # 16
])

label_names = ['Benign', 'Bot', 'DDoS', 'DoS GoldenEye', 'DoS Hulk', 'DoS Slowhttptest',
               'DoS Slowhttptest ', 'DoS slowloris', 'FTP-Patator', 'Heartbleed', 'Infiltration',
               'PortScan', 'SSH-Patator', 'Web Attack-Brute Force', 'Web Attack-SQL Injection',
               'Web Attack-XSS']

# 绘制混淆矩阵
plt.figure(figsize=(9, 7))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=label_names,
            yticklabels=label_names)
plt.xlabel('Predicted labels')
plt.ylabel('True labels')
plt.title('Confusion Matrix on CMCC-Kail')
plt.show()

# 计算综合准确率
diagonal_sum = np.trace(conf_matrix)
total_sum = np.sum(conf_matrix)
accuracy = diagonal_sum / total_sum
print(total_sum)
print('Accuracy: {:.3f}%'.format(accuracy * 100))
