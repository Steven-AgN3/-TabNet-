import os
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns
from Tool.timer.my_timer import timer
from sklearn.metrics import accuracy_score, confusion_matrix
from pytorch_tabnet.tab_model import TabNetClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

sampled_dataset = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Composite_Data\\'
                              'Final_Composite_data.csv')
# 获取列名
column_names = sampled_dataset.columns.tolist()
print(column_names)

# 训练日志路径
log_path = 'G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test\TabNet\\train_log'

# 将标签编码为整数
label_encoder = LabelEncoder()
sampled_dataset['Label'] = label_encoder.fit_transform(sampled_dataset['Label'])
# 获取标签映射
label_mapping = dict(zip(label_encoder.classes_, label_encoder.transform(label_encoder.classes_)))
label_names = [i for i in label_mapping.keys()]
print(label_names)

# 划分特征和标签
X = sampled_dataset.iloc[:, :-1].values
y = sampled_dataset.iloc[:, -1].values

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)


def load_model_and_predict():
    """
    函数说明：加载模型文件, 并进行预测
    :return: 无返回值
    """
    timer.start()
    # 加载模型
    model_path = 'G:\Introduction to Computers\Intrusion_Detection_System\Model_Train_and_Test\TabNet\TabNet_model'
    saved_filename = os.path.join(model_path, '0.940.zip')
    loaded_clf = TabNetClassifier()
    loaded_clf.load_model(saved_filename)
    loaded_predict = loaded_clf.predict(X_test)
    accuracy = accuracy_score(y_test, loaded_predict)
    print(f'最佳模型的预测正确率为：{accuracy}')
    timer.stop_and_print_elapsed_time()
    return loaded_predict


predict_label = load_model_and_predict()

with open('G:\Introduction to Computers\Intrusion_Detection_System\Model_Parameter'
          '\TabNet\预测结果与真实结果.txt', 'a+') as f:
    f.write(f'真实标签：{str(list(y_test))}')
    f.write('\n')
    f.write(f'预测标签：{str(list(predict_label))}')

cm = confusion_matrix(y_test, predict_label)
plt.figure(figsize=(9, 7))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=label_names,
            yticklabels=label_names)
plt.xlabel('Predicted labels')
plt.ylabel('True labels')
plt.title('Confusion Matrix')
plt.show()
