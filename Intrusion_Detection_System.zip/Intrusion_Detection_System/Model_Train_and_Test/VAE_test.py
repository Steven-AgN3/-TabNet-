import torch
import pandas as pd
import torch.nn as nn
import seaborn as sns
from Model.VAE import VAE
import torch.optim as optim
from matplotlib import pyplot as plt
from Tool.device import device_detection
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset

# 读取采样获得的数据集
sampled_dataset = pd.read_csv('G:\人工智能方向课\项目实训\Dataset\Final_Dataset\Sampled_Data\\Sampled_Benign_normalized_data.csv')

# 将标签编码为整数
label_encoder = LabelEncoder()
sampled_dataset['Label'] = label_encoder.fit_transform(sampled_dataset['Label'])
# 获取标签映射
label_mapping = dict(zip(label_encoder.classes_, label_encoder.transform(label_encoder.classes_)))
label_names = [i for i in label_mapping.keys()]

# 划分特征和标签
X = sampled_dataset.iloc[:, :-1].values
y = sampled_dataset.iloc[:, -1].values

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换为PyTorch张量
# 转换为PyTorch张量
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.long)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test, dtype=torch.long)

# 创建 DataLoader
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
test_dataset = TensorDataset(X_test_tensor, y_test_tensor)
# 定义epochs以及batch_size
epochs = 128
batch_size = 512
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# 初始化 VAE 模型
input_size_ = 69  # Number of features
latent_size_ = 64  # Number of hidden units

VAE_model = VAE(input_size_, latent_size_)
VAE_model.update_latent_size(latent_size_)
# 定义损失函数、学习率以及优化器
# 使用交叉熵损失函数
criterion = nn.MSELoss()
# 定义学习率
learning_rate = 0.001
# 使用Adam优化器
optimizer = optim.Adam(VAE_model.parameters(), lr=learning_rate)

# 定义列表保存epochs和每轮epoch后的损失函数
epochs_list = []
train_loss_list = []
val_loss_list = []


def fit():
    # 定义device为GPU或CPU
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print("Pytorch是否可调用GPU：", torch.cuda.is_available())

    # 将模型和损失函数移动到GPU
    VAE_model.to(device)
    criterion.to(device)
    print('model是否位于GPU:', next(VAE_model.parameters()).is_cuda)

    # 训练模型
    for epoch in range(epochs):
        VAE_model.train()
        train_loss = 0.
        for inputs, _ in train_loader:  # 修改此处，不使用标签
            inputs = inputs.to(device)
            optimizer.zero_grad()
            outputs = VAE_model(inputs)
            reconstruction, _, _ = outputs
            loss = criterion(reconstruction, inputs)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        VAE_model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for inputs, _ in test_loader:
                inputs = inputs.to(device)
                outputs = VAE_model(inputs)
                reconstruction, _, _ = outputs
                loss = criterion(reconstruction, inputs)
                val_loss += loss.item()

        # 计算平均损失
        train_loss /= len(train_loader)
        val_loss /= len(test_loader)
        # 添加每个epoch的损失函数值到列表中
        epochs_list.append(epoch + 1)
        train_loss_list.append(train_loss)
        val_loss_list.append(val_loss)
        # 打印训练集和验证集上的损失函数值
        print(f"Epoch {epoch + 1}/{epochs}, Train Loss: {train_loss}, Validation Loss: {val_loss}")


def plot_confusion_matrix(model, test_loader_):
    model.eval()
    device = next(model.parameters()).device
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for inputs, labels in test_loader_:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    cm = confusion_matrix(all_labels, all_preds)
    plt.figure(figsize=(9, 7))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=label_names,
                yticklabels=label_names)
    plt.xlabel('Predicted labels')
    plt.ylabel('True labels')
    plt.title('Confusion Matrix')
    plt.show()


# 函数调用
device_detection.device_detection()
fit()
# plot_confusion_matrix(VAE_model, test_loader)

# 绘制梯度迭代折线图
plt.figure(figsize=(8, 6))
plt.plot(epochs_list, train_loss_list, marker='o', linestyle='-', label='Train Loss')
plt.plot(epochs_list, val_loss_list, marker='o', linestyle='-', label='Validation Loss')
plt.title('Loss Over Number of Epochs')
plt.xlabel('Number of Epochs')
plt.ylabel('Loss')
plt.legend()  # 添加图例
plt.show()
