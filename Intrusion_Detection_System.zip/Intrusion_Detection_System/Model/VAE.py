import torch
import torch.nn as nn


class VAE(nn.Module):
    def __init__(self, input_size, latent_size, bn_momentum=0.1):
        super(VAE, self).__init__()

        # Encoder
        self.encoder = nn.Sequential(
            nn.Linear(input_size, 128),
            nn.LeakyReLU(),
            nn.BatchNorm1d(128, momentum=bn_momentum),  # Batch Normalization
            nn.Linear(128, 256),
            nn.LeakyReLU(),
            nn.BatchNorm1d(256, momentum=bn_momentum),
            nn.Linear(256, 512),
            nn.LeakyReLU(),
            nn.BatchNorm1d(512, momentum=bn_momentum),
            nn.Linear(512, 256),
            nn.LeakyReLU(),
            nn.BatchNorm1d(256, momentum=bn_momentum),
            nn.Linear(256, 128),
            nn.LeakyReLU(),
            nn.BatchNorm1d(128, momentum=bn_momentum),
            nn.Linear(128, latent_size * 2)  # *2 for mean and log-variance
        )

        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(latent_size, 128),
            nn.LeakyReLU(),
            nn.BatchNorm1d(128, momentum=bn_momentum),
            nn.Linear(128, 256),
            nn.LeakyReLU(),
            nn.BatchNorm1d(256, momentum=bn_momentum),
            nn.Linear(256, 512),
            nn.LeakyReLU(),
            nn.BatchNorm1d(512, momentum=bn_momentum),
            nn.Linear(512, 256),
            nn.LeakyReLU(),
            nn.BatchNorm1d(256, momentum=bn_momentum),
            nn.Linear(256, 128),
            nn.LeakyReLU(),
            nn.BatchNorm1d(128, momentum=bn_momentum),
            nn.Linear(128, input_size),
            nn.Sigmoid()
        )

    @staticmethod
    def reparameterize(mean, log_var):
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mean + eps * std

    def forward(self, x):
        # Encode
        encoding = self.encoder(x)

        # Adjust the shape of encoding
        encoding = encoding.squeeze(1)  # Remove the extra dimension

        mean, log_var = encoding.chunk(2, dim=1)

        # Reparameterize
        z = self.reparameterize(mean, log_var)

        # Decode
        reconstruction = self.decoder(z)

        return reconstruction, mean, log_var

    def update_latent_size(self, latent_size):
        # Update latent size dynamically
        self.encoder[-1] = nn.Linear(self.encoder[-1].in_features, latent_size * 2)
        self.decoder[0] = nn.Linear(latent_size, self.decoder[0].out_features)
